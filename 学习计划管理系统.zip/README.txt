Adaptive Study Scheduler（自適應學習時間安排器）
Daily Realistic Final Version（每日現實化最終版）

New realism improvements（新增現實化功能）
1. Actual Study Time（實際學習時間）
   - Timer completion records real study time.
   - Finish Now records elapsed timer time.
   - Manual completion records the planned time and is marked as manual.
   - 10-second Demo Timer only demonstrates the reminder and does NOT complete the real session.

2. Edit Course（編輯課程）
   - Course name, Difficulty, Priority, and Exam Date can be updated.
   - Existing course sessions keep the same course identity.

3. Maximum 90-minute sessions（單次最多90分鐘）
   - Longer daily allocations are automatically split.

4. Weekly Target change warning（每週目標修改提醒）
   - Changing the weekly goal after a plan exists marks the current plan for regeneration.

5. Sunday reality warning（星期日現實提醒）
   - If more than 6 hours remains on Sunday, the program warns that the weekly goal may be unrealistic.

6. Weekly progress uses Actual Study Time（每週進度依實際時間計算）.

Limitation（限制）
The HTML page must remain open for timer reminders.
